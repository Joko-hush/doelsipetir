<section id="top">
    <div class="container bg-primary">

    </div>

</section>
<section id="dikmil">
    <div class="container">
        <div class="section-title">
            <h2><?= $judul; ?></h2>
        </div>
    </div>

</section>