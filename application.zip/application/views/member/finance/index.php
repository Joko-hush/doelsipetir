<section id="hero" class="d-flex align-items-center justify-content-center">
    <div class="container" data-aos="fade-up">

        <figure>
            <figcaption class="figure-caption text-warning">Maaf Halaman ini masih dalam Proses Pengembangan</figcaption>
            <img src="<?= base_url('assets/img/'); ?>abaut.png" alt="Sedang dalam proses perencanaan" class="figure-img img-thumbnail" width="450">

        </figure>

    </div>
</section><!-- End Hero -->